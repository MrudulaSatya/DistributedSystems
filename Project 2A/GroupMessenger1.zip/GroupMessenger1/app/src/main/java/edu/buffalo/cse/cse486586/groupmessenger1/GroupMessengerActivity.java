package edu.buffalo.cse.cse486586.groupmessenger1;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {

    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    static final String REMOTE_PORT0 = "11108";
    static final String REMOTE_PORT1 = "11112";
    static final String REMOTE_PORT2 = "11116";
    static final String REMOTE_PORT3 = "11120";
    static final String REMOTE_PORT4 = "11124";
    static final int SERVER_PORT = 10000;
    int sequenceNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());

        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        Log.e(TAG, myPort);
        try {

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        final EditText editText = (EditText) findViewById(R.id.editText1);

        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
        Button send = (Button) findViewById(R.id.button4);
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                    String msg = editText.getText().toString() + "\n";
                    Log.v(TAG,msg);
                    editText.setText(""); // This is one way to reset the input box.
                    TextView localTextView = (TextView) findViewById(R.id.textView1);
                    localTextView.append("\t" + msg); // This is one way to display a string.
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
                
            }
        });


    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            Log.v(TAG,"server doinbackground started");
            ServerSocket serverSocket = sockets[0];
            Log.e(TAG,sockets[0].toString());
            /*
             * TODO: Fill in your server code that receives messages and passes them
             * to onProgressUpdate().
             *
             * Resources used:
             * https://docs.oracle.com/javase/tutorial/networking/sockets/readingWriting.html
             * https://docs.oracle.com/javase/tutorial/networking/sockets/clientServer.html
             */
            try {
                Socket socket ;
                String message;
                //int flag = 1;
                while( true) {
                    socket = serverSocket.accept();
                    Log.v(TAG, "server socket accepted");
                    BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    Log.v(TAG, "input stream reader buffer created");
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    Log.v(TAG, "output stream reader created");
                    message = input.readLine();
                    Log.v(TAG,"server message received");
                    out.println("ACK");
                    publishProgress(message);
                }
            } catch (IOException e) { }
            catch (NullPointerException ex) { }
            catch (Exception f) { }
            return null;
        }

        private Uri buildUri(String scheme, String authority) {
            Uri.Builder uriBuilder = new Uri.Builder();
            uriBuilder.authority(authority);
            uriBuilder.scheme(scheme);
            return uriBuilder.build();
        }
        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");


            final Uri mUri;
            /** content provider **/
            String key = String.valueOf(sequenceNumber);
            String value = strReceived;
            GroupMessengerProvider groupMessengerProvider = new GroupMessengerProvider();
            ContentValues keyValueToInsert = new ContentValues();
            keyValueToInsert.put("key",key);
            sequenceNumber += 1;
            keyValueToInsert.put("value",value);
            mUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger1.provider");
            Uri newUri = getContentResolver().insert(mUri, keyValueToInsert);
            return;
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            try {
                Log.v(TAG, "client doinbackground started");
                Log.v(TAG, "client socket creating...");
                String message0, message1, message2, message3, message4;
                String msgToSend = msgs[0];

                //SOCKET 0
                Socket socket0 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT0));
                Log.v(TAG, "SOCKET 0 CREATED");
                PrintWriter out0 = new PrintWriter(socket0.getOutputStream(), true);
                out0.println(msgToSend);
                Log.v(TAG, "message 0 sent");
                BufferedReader input0 = new BufferedReader(new InputStreamReader(socket0.getInputStream()));
                Thread.sleep(7); // waiting to receive ACK from server
                message0 = input0.readLine();
                Log.v(TAG, message0);
                if (message0.equals("ACK")) {
                    out0.flush(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    out0.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    socket0.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    Log.v(TAG, "socket 0 closed");
                }

                //SOCKET 1
                Socket socket1 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT1));
                Log.v(TAG, "SOCKET 1 CREATED");
                PrintWriter out1 = new PrintWriter(socket1.getOutputStream(), true);
                out1.println(msgToSend);
                Log.v(TAG, "MESSAGE 1 SENT");
                BufferedReader input1 = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
                Thread.sleep(7); // waiting to receive ACK from server
                message1 = input1.readLine();
                Log.v(TAG, message1);
                if (message1.equals("ACK")) {
                    out1.flush(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    out1.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    socket1.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    Log.v(TAG, "socket 1 closed");
                }
                //SOCKET 2
                Socket socket2 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT2));
                Log.v(TAG, "SOCKET 2 CREATED");
                PrintWriter out2 = new PrintWriter(socket2.getOutputStream(), true);
                out2.println(msgToSend);
                Log.v(TAG, "MESSAGE 2 SENT");
                BufferedReader input2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
                Thread.sleep(7); // waiting to receive ACK from server
                message2 = input2.readLine();
                Log.v(TAG, message2);


                if (message2.equals("ACK")) {
                    out2.flush(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    out2.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    socket2.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    Log.v(TAG, "socket 2 closed");
                }
                //SOCKET 3
                Socket socket3 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT3));
                Log.v(TAG, "SOCKET 3 CREATED");
                PrintWriter out3 = new PrintWriter(socket3.getOutputStream(), true);
                out3.println(msgToSend);
                Log.v(TAG, "MESSAGE 3 SENT");
                BufferedReader input3 = new BufferedReader(new InputStreamReader(socket3.getInputStream()));
                Thread.sleep(7); // waiting to receive ACK from server
                message3 = input3.readLine();
                Log.v(TAG, message3);
                if (message3.equals("ACK")) {
                    out3.flush(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    out3.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    socket3.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    Log.v(TAG, "socket 3 closed");
                }

                /*
                 * TODO: Fill in your client code that sends out a message.
                 * Resources used:
                 * https://docs.oracle.com/javase/tutorial/networking/sockets/readingWriting.html
                 * https://docs.oracle.com/javase/tutorial/networking/sockets/clientServer.html
                 */

                //SOCKET 4
                Socket socket4 = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(REMOTE_PORT4));
                Log.v(TAG, "SOCKET 4 CREATED");
                PrintWriter out4 = new PrintWriter(socket4.getOutputStream(), true);
                // use of println taken from https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                out4.println(msgToSend);
                Log.v(TAG, "message sent");
                BufferedReader input4 = new BufferedReader(new InputStreamReader(socket4.getInputStream()));
                Thread.sleep(7); // waiting to receive ACK from server
                message4 = input4.readLine();
                Log.v(TAG, message4);
                if (message4.equals("ACK")) {
                    out4.flush(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    out4.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    socket4.close(); //https://stackoverflow.com/questions/35694668/android-socket-client-not-receiving-from-java-server
                    Log.v(TAG, "socket 4 closed");
                }

            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException");
            } catch (InterruptedException ie){
                Log.e(TAG,"Sleep gave exception. Sleep didn't work");
            }

            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
}
